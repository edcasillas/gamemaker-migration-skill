Conv4to5
========

This zip file contains a conversion program to convert
Game Maker 4.x files into Game Maker 5.0 files that can
be read by Game Maker 5.0 and later. This program has
become necessary because Game Maker 5.1 can no longer
read version 4.x files. 

To convert a file, simply start the program. Next click
on the button convert, choose the name of the version 4.x
file and next choose a name for the new version 5.0 file.
Better use a different name for this, but this is no
required.

Mark Overmars